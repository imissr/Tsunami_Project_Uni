#include <iostream>
#include <omp.h>
// barriere ist ein Punkt bei dem alle threads warten müssen bis alle threads an diesem punkt angekommen sind
// avoid data races
// waiting for threads is a time waste

    void ohneBarriere(){

        int thread_id;
        #pragma omp parallel private(thread_id)
        {
            thread_id = omp_get_thread_num();
            std::cout << "Thread " << thread_id << " is doing something " << std::endl;

            if (thread_id == 0)
            {
                std::cout << "Es gibt " << omp_get_num_threads() << std::endl;
            }
        }
    }

    void mitBarriere(){

        int thread_id;
        #pragma omp parallel private(thread_id)
        {
            thread_id = omp_get_thread_num();
            std::cout << "Thread " << thread_id << " is doing something " << std::endl;

            #pragma omp barrier
            if (thread_id == 0)
            {
                std::cout << "Es gibt " << omp_get_num_threads() << std::endl;
            }
        }
    }

int main(){
    
        ohneBarriere();
        std::cout << "-------------------" << std::endl;
        mitBarriere();  

        /*
        Was passiert : DIe ausgabe "Es gibt 8 " wird ohne die Barriere irgendwann ziwschendurch ausgegeben und nicht am ende 
        weil die threads nicht warten müssen bis alle threads an diesem punkt angekommen sind . wenn alle an diesem punkt angekommen sind wird weitergemacht
        */
}
