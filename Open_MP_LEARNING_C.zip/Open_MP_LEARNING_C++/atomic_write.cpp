#include <iostream>
#include <omp.h>

void ohneWrite(){
    int array[5] = {5,5,5,5,5};
    int sum = 0;
    #pragma omp parallel for
        for(int i = 0; i < 5; i++){
            sum = array[i]+ sum;
        }
    std::cout << sum << std::endl;
}

void mitWrite(){
    int array[5] = {5,5,5,5,5};
    int sum = 0;
    #pragma omp parallel for
        for(int i = 0; i < 5; i++){
            #pragma omp atomic write
            sum = array[i]+ sum;
        }
    std::cout << sum << std::endl;
}
int main(){
    mitWrite();
    std::cout << "-------------------" << std::endl;
    ohneWrite();
}

/*
In diesem Code wird die Direktive #pragma omp atomic write verwendet, um sicherzustellen, dass der Schreibzugriff auf die Variable sum atomar erfolgt.
Eine atomare Operation ist eine Operation,
die als Ganzes ausgeführt wird,
ohne von anderen Threads unterbrochen zu werden. 
In diesem Fall stellt #pragma omp atomic write sicher,
dass der Schreibzugriff auf sum atomar erfolgt,
sodass keine Dateninkonsistenzen auftreten,
wenn mehrere Threads gleichzeitig auf die Variable zugreifen.*/