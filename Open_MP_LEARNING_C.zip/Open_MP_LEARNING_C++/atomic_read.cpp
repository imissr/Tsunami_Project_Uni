#include <iostream>
#include <omp.h>

void mitAtomic()
{
    int max = -1;
    int values[10];
    for(int i = 0; i < 10; i++){
        values[i] = rand() % 100;
    }
    for(int i = 0; i < 10; i++){
        std::cout << values[i] << std::endl;
    }
    
    #pragma omp parallel
    for(int i = 0; i < 10; i++){
        if(values[i] > max){
            #pragma omp atomic read
            max = values[i];
        }
    }
    
    std::cout << "MAXIMUM: " << max << std::endl;
}

void ohneAtomic()
{
    int max = -1;
    int values[10];
    for(int i = 0; i < 10; i++){
        values[i] = rand() % 100;
    }
    for(int i = 0; i < 10; i++){
        std::cout << values[i] << std::endl;
    }
    
    #pragma omp parallel
    {
        #pragma omp for
        for(int i = 0; i < 10; i++){
            if(values[i] > max){
                max = values[i];
            }
        }
        
        #pragma omp barrier
        
        #pragma omp single
        std::cout << "threads: " << omp_get_num_threads() << std::endl;
    }
    
    std::cout << "MAXIMUM: " << max << std::endl;
}

void nurWerte(){
    int max = -1;
    #pragma omp parallel num_threads(16)
    {
        for(int i = 0; i < 1000; i++){
            max = i;
        }
        #pragma omp single
        std::cout << "threads: " << omp_get_num_threads() << std::endl;
    }
    std::cout << "MAXIMUM: " << max << std::endl;
}

int main()
{
    nurWerte();
    //mitAtomic();
    std::cout << "-------------------" << std::endl;
   //ohneAtomic();
}


// atomic read sagt das man eine variable liest und dabei kann nicht auf diese zugegriffen/ verändertt werden aber bei mir im code passiert da nix
