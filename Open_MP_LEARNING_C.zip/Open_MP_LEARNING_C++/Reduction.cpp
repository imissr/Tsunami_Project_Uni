#include <iostream>
#include <omp.h>


void reduction()
{
    /*
    Reduction ist eine Möglichkeit um shared variablen zu vermeiden
    */
    int i , sum =0;
    omp_set_num_threads(4);
    #pragma omp parallel
    {
        #pragma omp for reduction(+:sum)
        for (i = 0; i <= 100; i++)
        {
            sum += i;
        }
    }
    std::cout << sum << std::endl;
}

void reduction1(){
    int i , sum =0;
    omp_set_num_threads(4);

        #pragma omp parallel for reduction(+:sum)
        for (i = 0; i <= 100; i++)
        {
            sum += i;
        }
    
    std::cout << sum << std::endl;	
}
int main()
{
    reduction();
    reduction1();
}

//reduktion bedeutet das die threads eine private variable sum bekommen und sich hier die
//indizes aufteilen und dann am ende die summe zusammenrechnen und diese ist dann die globale summe

//reduktion ist auch gut für * / + - geeignet also minimum maximum bitweise sachen | und logische operatoren ||

// beides macht das gleiche im grunde also ergebnis ist in beiden fällen 5050