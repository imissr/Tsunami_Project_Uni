#include <omp.h>
#include <iostream>

int main() {
    int atomicValue = 0;
    int capturedValue;

    #pragma omp parallel num_threads(4)
    {
        #pragma omp atomic update
        atomicValue += 1;

        #pragma omp atomic capture
        capturedValue = atomicValue;

        #pragma omp barrier

        std::cout << "Thread " << omp_get_thread_num() << ": Atomic Value = " << atomicValue << ", Captured Value = " << capturedValue << std::endl;
    }

    return 0;
}
/*

In diesem Beispiel wird der atomare Wert atomicValue in einem parallelen Abschnitt von vier Threads aktualisiert.
 Nach der Aktualisierung wird der aktuelle Wert des atomaren Wertes mit der Direktive #pragma omp atomic capture erfasst und in der Variablen capturedValue gespeichert.
  Anschließend wird der Wert beider Variablen ausgegeben.

Die Ausgabe könnte wie folgt aussehen:


Thread 0: Atomic Value = 1, Captured Value = 1
Thread 1: Atomic Value = 2, Captured Value = 2
Thread 2: Atomic Value = 3, Captured Value = 3
Thread 3: Atomic Value = 4, Captured Value = 4

Wie Sie sehen können, wird der atomare Wert aktualisiert und dann der aktuelle Wert erfasst und in der Variablen capturedValue gespeichert.



Daniels einfache Erklärung: wenn du mit einem bestimmten wert weiterarbeiten willst kann du das tun indem du dann den wert in eine andere variable speicherst durch capture

*/