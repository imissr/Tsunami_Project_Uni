#include <iostream>
#include <omp.h>

#define MAX 8

 // soll zeigen das wenn jeder thread die variable um 1 erhöht dann kommt es vor das die variable nicht 8 ist sondern weniger
 // weil wenn 2 threads gleichzeitig die variable um 1 erhöhen dann wird die variable nur um 1 erhöht und nicht um 2

void mitAtomic()
{
    int i =0;

    #pragma omp parallel num_threads(MAX)
    {   
        #pragma omp atomic update
        i++;
    }
    std::cout << i << std::endl;
}

void ohneAtomic()
{
    int i =0;

    #pragma omp parallel num_threads(MAX)
    {   
        i++;
    }
    std::cout << i << std::endl;
}
int main()
{
    mitAtomic();
    std::cout << "-------------------" << std::endl;
    ohneAtomic();
}