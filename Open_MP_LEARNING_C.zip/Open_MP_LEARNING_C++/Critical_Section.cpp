//critical section prevents multiple threads from accessing a shared resource at the same time
//critical section is a block of code that accesses a shared resource (data structure or device) that must not be concurrently accessed by more than one thread of execution
//immer nur einer darf und dann kann der nächste

#include <iostream>
#include <omp.h>

#include <iostream>
#include <omp.h>
#include <cstdlib> // for rand function

#include <iostream>
#include <omp.h>
#include <cstdlib> // for rand function

#include <iostream>
#include <omp.h>
#include <cstdlib> // for rand function

int main()
{
    double values[20];

    for(int i = 0; i < 20; i++)
    {
        values[i] = static_cast<double>(rand()) / (RAND_MAX / 10.0); // generate random value between 0 and 10
        std::cout << values[i] << std::endl;
    }


    
    double max = values[0];


    #pragma omp parallel for num_threads(4)
    for(int i = 0; i < 20; i++)
    {
        if(values[i] > max){
        /*die erste abfrage fragt nur ob der wert den man gerade hat größer ist als der max wert
         der vielleicht schon veraltet ist weil eigentlich ein anderer thread schon einen größeren wert gefunden hat deswegen 
        ist die erste abfrage ein : hast du einen wert der größer ist als ein alter max wert wenn ja gucke dann in der critical section
        ob dieser wert auch größer als der aktuelle max wert ist 
        wenn ja dann setze den neuen wert als max wert*/
            #pragma omp critical
            {   
                if(values[i] > max){
                    // Critical section code here
                    std::cout << "Thread " << omp_get_thread_num() << " with value" <<values[i]<<" and old max is: "<<max<< std::endl;
                    max = values[i];
                }
            }
        }
    }
    std::cout << "Max: " << max << std::endl;        
}
