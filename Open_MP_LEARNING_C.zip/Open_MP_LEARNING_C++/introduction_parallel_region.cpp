#include <iostream>
#include <omp.h>

int main()
{
    #pragma omp parallel
    {
        int id = omp_get_thread_num();
        std::cout <<"Thread "<<id<< ": Hello World" << std::endl;

        #pragma omp single nowait
        {
            std::cout <<"Thread "<<id<< ": Only one thread executes this" << std::endl;
        }
    }
    return 0;
}
