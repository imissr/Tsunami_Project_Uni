#include <iostream>
#include <omp.h>

int main()
{
    int max = 0;

    #pragma omp parallel for collapse(2)
    for (int j = 0; j < 10; j++)
    {
        for (int i = 0; i < 10; i++)
        {
            #pragma omp atomic update
            max += i + j;
        } //der gesammte Lese-Änderungs-Schreibvorgang atomar ist
    }

    std::cout << max << std::endl;

    return 0;
}