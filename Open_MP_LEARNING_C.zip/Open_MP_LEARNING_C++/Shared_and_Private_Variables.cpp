#include <iostream>
#include <omp.h>

int main()
{
    int a = 1;
    int n = 10;
    #pragma omp parallel for shared(a,n) private(b)
    for (int j = 0; j < n; j++)
    {
        int b = a + j;
    }

    /*
    Loop Variablen sind private per default -> j ist privat
    Variablen welche innerhalb der for schleife /parallelen region definiert werden sind privat -> b ist privat
    Variablen welche außerhalb der for schleife definiert werden sind shared -> a ist shared

    Es ist am besten so wenig wie möglich shared variablen zu haben um den overhead zu minimieren
    */
    return 0;
}